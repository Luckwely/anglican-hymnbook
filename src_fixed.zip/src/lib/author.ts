import authorPhoto from '../assets/author.png';

/**
 * Your contact details, shown in the "À propos" panel (⋮ menu on the home page).
 * Edit the values below, and replace src/assets/author.png with your own photo.
 */
export const author = {
  name: 'Your Name',
  role: 'Developer of this app',
  photo: authorPhoto,
  email: 'your.email@example.com',
  phone: '+261 00 00 000 00',
  whatsapp: '261000000000', // international format, digits only (optional, '' to hide)
};
